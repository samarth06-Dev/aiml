# Q4: N-Queens Using Backtracking
# Experiment 2: Constraint Satisfaction Problems (CSP)
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

def is_safe(positions, row, col):
    # Check every queen already placed in an earlier column.
    for old_col in range(col):
        old_row = positions[old_col]
        if old_row == row:
            return False  # Same row is not allowed.
        if abs(old_row - row) == abs(old_col - col):
            return False  # Equal row/column difference means same diagonal.
    return True

def solve_n_queens(n, positions, col):
    # All columns have a queen: a complete solution has been found.
    if col == n:
        return True

    # Try each row as a possible position in this column.
    for row in range(n):
        if is_safe(positions, row, col):
            positions[col] = row  # Make a tentative choice.
            if solve_n_queens(n, positions, col + 1):
                return True
            positions[col] = -1  # Undo the choice (backtrack).
    return False

n = int(input("Enter N (minimum 4): "))
if n < 4:
    print("Please enter N >= 4.")
else:
    positions = [-1] * n  # positions[col] stores the queen's row.
    if solve_n_queens(n, positions, 0):
        print("One valid board configuration:")
        for row in range(n):
            line = []
            for col in range(n):
                line.append("Q" if positions[col] == row else ".")
            print(" ".join(line))
        print("Solution found.")
    else:
        print("No solution found.")

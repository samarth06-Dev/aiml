AI/ML Practical Exam - Beginner Code Pack

There are 33 standalone Python programs, one for each question in the supplied problem statement PDF.

Before running:
1. Install Python 3.
2. Install the common packages: pip install pandas numpy matplotlib scikit-learn
3. For Q29: pip install mlxtend
4. For Q30 and Q31: pip install tensorflow
5. For CSV-based questions, place the required CSV in the same folder as the script and check the expected column names in the study guide.
6. Run a script with: python q01_....py

Built-in scikit-learn datasets are used for selected questions so those examples do not require Kaggle downloads.
CSV-based scripts deliberately state the expected column names; rename your own dataset columns or edit the feature list to match.

Note: Q16, Q30 and Q31 are educational examples. They are not medical, financial or institutional decision systems.

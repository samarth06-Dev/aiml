# Q31: Student Pass/Fail Prediction Using ANN
# Experiment 8: Artificial Neural Networks
# Dataset / setup: Student performance CSV. Expected inputs: `attendance`, `study_hours`, `internal_marks`, `assignment_score`; target is derived from `final_score >= 40`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

# Install TensorFlow if needed: pip install tensorflow
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# Expected columns: attendance, study_hours, internal_marks, assignment_score, final_score.
df = pd.read_csv("student_performance.csv")
features = ["attendance", "study_hours", "internal_marks", "assignment_score"]
X = df[features].fillna(df[features].median())
# Create the binary target: final score >= 40 means pass in this example.
y = (df["final_score"] >= 40).astype(int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = Sequential([
    Dense(16, activation="relu", input_shape=(X_train_scaled.shape[1],)),
    Dense(8, activation="relu"),
    Dense(1, activation="sigmoid")
])
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
model.fit(X_train_scaled, y_train, epochs=30, batch_size=16, validation_split=0.1)

probabilities = model.predict(X_test_scaled)
predictions = (probabilities >= 0.5).astype(int).ravel()
print("Accuracy:", accuracy_score(y_test, predictions))
print("Precision:", precision_score(y_test, predictions, zero_division=0))
print("Recall:", recall_score(y_test, predictions, zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

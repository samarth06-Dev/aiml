# Q19: Student Performance Classification Using KNN
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: Student performance CSV. Expected columns: `attendance`, `study_hours`, `internal_marks`, and `final_score`; change feature names if needed.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix

# Expected columns: attendance, study_hours, Previous Scores, final_score.
df = pd.read_csv("student_performance.csv")
features = ["Sample Question Papers Practiced", "Hours Studied", "Previous Scores"]
X = df[features].fillna(df[features].median())

# Create simple target categories from final score if no category is supplied.
y = pd.cut(df["Performance Index"], bins=[-1, 40, 70, 100],
           labels=["Low", "Average", "High"])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

for k in [3, 5, 7]:
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train_scaled, y_train)
    predictions = model.predict(X_test_scaled)
    print("K =", k, "Accuracy =", accuracy_score(y_test, predictions))

# Show classification results for K=5.
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train_scaled, y_train)
predictions = model.predict(X_test_scaled)
print("Precision (macro):", precision_score(y_test, predictions, average="macro", zero_division=0))
print("Recall (macro):", recall_score(y_test, predictions, average="macro", zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

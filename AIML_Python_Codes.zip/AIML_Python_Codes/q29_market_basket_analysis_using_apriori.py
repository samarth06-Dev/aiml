# Q29: Market Basket Analysis Using Apriori
# Experiment 7: Apriori Association Rule Mining
# Dataset / setup: No external dataset required for this sample; it contains 10 illustrative baskets. Requires `mlxtend` and `pandas`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

# Install the library once if needed: pip install mlxtend pandas
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# Each inner list represents one customer\'s basket (at least 10 transactions).
transactions = [
    ["Milk", "Bread", "Butter"],
    ["Bread", "Diapers", "Beer"],
    ["Milk", "Bread", "Diapers", "Beer"],
    ["Milk", "Bread", "Butter"],
    ["Bread", "Butter"],
    ["Milk", "Diapers", "Beer"],
    ["Bread", "Diapers"],
    ["Milk", "Bread", "Butter", "Diapers"],
    ["Milk", "Bread"],
    ["Diapers", "Beer"]
]

# Convert baskets into a True/False table: one column for each item.
encoder = TransactionEncoder()
encoded = encoder.fit(transactions).transform(transactions)
df = pd.DataFrame(encoded, columns=encoder.columns_)
print("One-hot transaction table:\n", df)

# Find item combinations appearing in at least 20% of baskets.
frequent_items = apriori(df, min_support=0.2, use_colnames=True)
print("Frequent itemsets:\n", frequent_items)

# Generate rules whose confidence is at least 50%.
rules = association_rules(frequent_items, metric="confidence", min_threshold=0.5)
print("Association rules:")
print(rules[["antecedents", "consequents", "support", "confidence", "lift"]])

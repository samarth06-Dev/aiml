# Q27: Mall Customer Clustering
# Experiment 6: Ensemble Learning and K-Means Clustering
# Dataset / setup: Mall Customers CSV. Expected headers: `Annual Income (k$)` and `Spending Score (1-100)`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# Load the common Mall Customers dataset.
df = pd.read_csv("Mall_Customers.csv")
features = ["Annual Income (k$)", "Spending Score (1-100)"]
X = df[features].dropna()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Elbow curve for K = 1 to 10.
inertia_values = []
for k in range(1, 11):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertia_values.append(km.inertia_)
plt.plot(range(1, 11), inertia_values, marker="o")
plt.xlabel("K")
plt.ylabel("Inertia")
plt.title("Elbow Curve")
plt.show()

k = 5  # Replace with the K suggested by your elbow plot.
model = KMeans(n_clusters=k, random_state=42, n_init=10)
labels = model.fit_predict(X_scaled)

# Plot each customer and the centroid locations in original units.
plt.scatter(X.iloc[:, 0], X.iloc[:, 1], c=labels)
centres = scaler.inverse_transform(model.cluster_centers_)
plt.scatter(centres[:, 0], centres[:, 1], marker="X", s=200, label="Centroids")
plt.xlabel(features[0])
plt.ylabel(features[1])
plt.legend()
plt.title("Mall Customer Clusters")
plt.show()

print("Number of customers in each cluster:")
print(pd.Series(labels).value_counts().sort_index())

# Q23: Compare Random Forest and Decision Tree
# Experiment 6: Ensemble Learning and K-Means Clustering
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

# Load the Iris classification dataset.
data = load_iris()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

models = {
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42)
}

for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print("\n", name)
    print("Accuracy:", accuracy_score(y_test, predictions))
    print("Precision (macro):", precision_score(y_test, predictions, average="macro"))
    print("Recall (macro):", recall_score(y_test, predictions, average="macro"))
    print("F1-score (macro):", f1_score(y_test, predictions, average="macro"))

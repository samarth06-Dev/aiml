# Q32: Compare Decision Tree, KNN and Naive Bayes
# Experiment 9: Integrated Classification and ML Pipeline
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

# A labelled, two-class dataset is loaded from scikit-learn.
data = load_breast_cancer()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Pipeline scales features for KNN; it is also harmless for GaussianNB.
models = {
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "KNN": make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5)),
    "Gaussian Naive Bayes": make_pipeline(StandardScaler(), GaussianNB())
}

results = []
for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, zero_division=0)
    recall = recall_score(y_test, predictions, zero_division=0)
    f1 = f1_score(y_test, predictions, zero_division=0)
    results.append([name, accuracy, precision, recall, f1])
    print("\n", name)
    print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

# Display a simple comparison table.
print("\nModel comparison:")
print("Model | Accuracy | Precision | Recall | F1")
for row in results:
    print(row[0], *[round(value, 3) for value in row[1:]], sep=" | ")

# Q18: Iris Flower Classification Using KNN
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Load flower measurements and species labels.
data = load_iris()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Learn mean and standard deviation from training data only.
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Compare three neighbour counts.
for k in [3, 5, 7]:
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train_scaled, y_train)
    predictions = model.predict(X_test_scaled)
    print("K =", k, "Accuracy =", accuracy_score(y_test, predictions))

# Example prediction for a new flower (measurements in the Iris feature order).
new_flower = [[5.1, 3.5, 1.4, 0.2]]
new_flower_scaled = scaler.transform(new_flower)
chosen_model = KNeighborsClassifier(n_neighbors=5)
chosen_model.fit(X_train_scaled, y_train)
print("Predicted species:", data.target_names[chosen_model.predict(new_flower_scaled)[0]])

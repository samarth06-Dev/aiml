# Q24: Titanic Survival Prediction Using Random Forest
# Experiment 6: Ensemble Learning and K-Means Clustering
# Dataset / setup: Titanic CSV. Expected columns: `Survived`, `Pclass`, `Sex`, `Age`, `SibSp`, `Parch`, `Fare`, and `Embarked`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

# Expected Titanic CSV columns include Survived, Pclass, Sex, Age, SibSp, Parch, Fare, Embarked.
df = pd.read_csv("titanic.csv")
features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Ticket"]
X = df[features].copy()
y = df["Survived"]

# Fill missing numerical and categorical values.
X["Age"] = X["Age"].fillna(X["Age"].median())
X["Fare"] = X["Fare"].fillna(X["Fare"].median())
X["Ticket"] = X["Ticket"].fillna(X["Ticket"].mode()[0])

# Convert Sex and Embarked categories into numeric columns.
X = pd.get_dummies(X, columns=["Sex", "Ticket"], drop_first=True, dtype=int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, predictions))
print("Precision:", precision_score(y_test, predictions, zero_division=0))
print("Recall:", recall_score(y_test, predictions, zero_division=0))
print("F1-score:", f1_score(y_test, predictions, zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

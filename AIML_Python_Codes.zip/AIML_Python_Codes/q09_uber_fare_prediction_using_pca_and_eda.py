# Q9: Uber Fare Prediction Using PCA and EDA
# Experiment 4: EDA, PCA and Regression
# Dataset / setup: Kaggle Uber Fares CSV. This code expects `fare_amount`, pickup/dropoff longitude and latitude, `passenger_count`, and optionally `pickup_datetime`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Download the Uber Fares CSV from Kaggle and place it beside this program.
df = pd.read_csv("uber.csv")
print("Shape:", df.shape)
print("Data types:\n", df.dtypes)
print("Missing values:\n", df.isnull().sum())
print("Summary:\n", df.describe())

# Remove rows with invalid or missing fare values.
df = df.dropna(subset=["fare_amount", "pickup_longitude", "pickup_latitude",
                       "dropoff_longitude", "dropoff_latitude", "passenger_count"])
df = df[(df["fare_amount"] > 0) & (df["fare_amount"] < 500)]
df = df[(df["passenger_count"] > 0) & (df["passenger_count"] <= 6)]

# Convert pickup time into a numeric hour feature, when that column exists.
if "pickup_datetime" in df.columns:
    df["pickup_datetime"] = pd.to_datetime(df["pickup_datetime"], errors="coerce")
    df["pickup_hour"] = df["pickup_datetime"].dt.hour

features = ["pickup_longitude", "pickup_latitude", "dropoff_longitude",
            "dropoff_latitude", "passenger_count"]
if "pickup_hour" in df.columns:
    features.append("pickup_hour")
X = df[features].fillna(df[features].median())
y = df["fare_amount"]

# Basic EDA plots.
df["fare_amount"].hist(bins=30)
plt.title("Uber Fare Distribution")
plt.xlabel("Fare amount")
plt.ylabel("Frequency")
plt.show()

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# Fit the scaler only on training features to avoid data leakage.
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Model 1: Linear Regression on the original standardized features.
model_original = LinearRegression()
model_original.fit(X_train_scaled, y_train)
pred_original = model_original.predict(X_test_scaled)

# Model 2: PCA keeps enough components to explain 95% of training variance.
pca = PCA(n_components=0.95)
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)
model_pca = LinearRegression()
model_pca.fit(X_train_pca, y_train)
pred_pca = model_pca.predict(X_test_pca)

def show_metrics(name, actual, predicted):
    rmse = mean_squared_error(actual, predicted) ** 0.5
    print(name, "R2:", round(r2_score(actual, predicted), 3),
          "RMSE:", round(rmse, 3),
          "MAE:", round(mean_absolute_error(actual, predicted), 3))

show_metrics("Without PCA", y_test, pred_original)
show_metrics("With PCA", y_test, pred_pca)
print("Original feature count:", X_train.shape[1])
print("PCA component count:", pca.n_components_)
print("Explained variance:", pca.explained_variance_ratio_.sum())

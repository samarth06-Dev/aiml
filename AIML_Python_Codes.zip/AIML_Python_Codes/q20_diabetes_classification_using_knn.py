# Q20: Diabetes Classification Using KNN
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: Pima Indians Diabetes CSV. Expected target `Outcome` and columns such as Glucose, BloodPressure, SkinThickness, Insulin and BMI.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, accuracy_score

# Expected Pima file: diabetes.csv, target column Outcome (0/1).
df = pd.read_csv("diabetes.csv")
invalid_zero_columns = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
for column in invalid_zero_columns:
    if column in df.columns:
        df[column] = df[column].replace(0, float("nan"))

X = df.drop(columns=["Outcome"])
y = df["Outcome"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Imputer and scaler are fitted only on the training data.
imputer = SimpleImputer(strategy="median")
X_train_clean = imputer.fit_transform(X_train)
X_test_clean = imputer.transform(X_test)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_clean)
X_test_scaled = scaler.transform(X_test_clean)

for k in [3, 5, 7, 9]:
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train_scaled, y_train)
    predictions = model.predict(X_test_scaled)
    print("K =", k, "Accuracy =", accuracy_score(y_test, predictions),
          "Precision =", precision_score(y_test, predictions, zero_division=0),
          "Recall =", recall_score(y_test, predictions, zero_division=0),
          "F1 =", f1_score(y_test, predictions, zero_division=0))

print("Confusion matrix for last K:\n", confusion_matrix(y_test, predictions))

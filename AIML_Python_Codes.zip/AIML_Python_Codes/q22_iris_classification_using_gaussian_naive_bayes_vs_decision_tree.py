# Q22: Iris Classification Using Gaussian Naive Bayes vs Decision Tree
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

# Load the same Iris dataset for both classifiers.
data = load_iris()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

models = {
    "Gaussian Naive Bayes": GaussianNB(),
    "Decision Tree": DecisionTreeClassifier(random_state=42)
}

for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print("\n", name)
    print("Accuracy:", accuracy_score(y_test, predictions))
    print("Precision (macro):", precision_score(y_test, predictions, average="macro"))
    print("Recall (macro):", recall_score(y_test, predictions, average="macro"))
    print("F1 (macro):", f1_score(y_test, predictions, average="macro"))
    print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

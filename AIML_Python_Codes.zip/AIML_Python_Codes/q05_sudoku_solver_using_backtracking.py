# Q5: Sudoku Solver Using Backtracking
# Experiment 2: Constraint Satisfaction Problems (CSP)
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

# 0 represents an empty Sudoku cell. Keep True to run the sample puzzle.
USE_SAMPLE = True
if USE_SAMPLE:
    board = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9]
    ]
else:
    # Enter 9 lines; each line must contain 9 integers. Use 0 for blanks.
    board = []
    for row_number in range(9):
        row = list(map(int, input(f"Enter row {row_number + 1}: ").split()))
        if len(row) != 9 or any(value < 0 or value > 9 for value in row):
            raise ValueError("Each row must contain 9 values from 0 to 9.")
        board.append(row)

def find_empty():
    # Return the first empty cell as (row, column); return None if full.
    for row in range(9):
        for col in range(9):
            if board[row][col] == 0:
                return row, col
    return None

def is_valid(row, col, number):
    # Check the selected row.
    if number in board[row]:
        return False

    # Check the selected column.
    for r in range(9):
        if board[r][col] == number:
            return False

    # Find the top-left corner of the cell's 3 x 3 subgrid.
    box_row = (row // 3) * 3
    box_col = (col // 3) * 3
    for r in range(box_row, box_row + 3):
        for c in range(box_col, box_col + 3):
            if board[r][c] == number:
                return False
    return True

def solve():
    empty = find_empty()
    if empty is None:
        return True  # No empty cells remain: puzzle solved.

    row, col = empty
    for number in range(1, 10):
        if is_valid(row, col, number):
            board[row][col] = number  # Try a valid number.
            if solve():
                return True
            board[row][col] = 0  # Undo a failed attempt.
    return False

def validate_solution():
    # Every row, column and 3 x 3 box must contain 1 through 9.
    expected = set(range(1, 10))
    for i in range(9):
        if set(board[i]) != expected:
            return False
        if {board[r][i] for r in range(9)} != expected:
            return False
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            values = {board[r][c] for r in range(br, br + 3)
                      for c in range(bc, bc + 3)}
            if values != expected:
                return False
    return True

if solve() and validate_solution():
    print("Solved Sudoku:")
    for row in board:
        print(*row)
else:
    print("The puzzle has no valid solution.")

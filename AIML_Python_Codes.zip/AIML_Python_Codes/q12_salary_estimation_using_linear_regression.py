# Q12: Salary Estimation Using Linear Regression
# Experiment 4: EDA, PCA and Regression
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Small example dataset; replace these values with your provided salary data.
experience = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
salary = np.array([25000, 30000, 35000, 40000, 48000,
                   52000, 60000, 65000, 72000, 80000])

X_train, X_test, y_train, y_test = train_test_split(
    experience, salary, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Slope:", model.coef_[0])
print("Intercept:", model.intercept_)
print("Regression equation: Salary =",
      round(model.coef_[0], 2), "* Experience +", round(model.intercept_, 2))
print("R2:", r2_score(y_test, predictions))
print("RMSE:", mean_squared_error(y_test, predictions) ** 0.5)
print("MAE:", mean_absolute_error(y_test, predictions))

# Plot all example observations and the fitted regression line.
line_x = np.linspace(experience.min(), experience.max(), 100).reshape(-1, 1)
line_y = model.predict(line_x)
plt.scatter(experience, salary, label="Actual data")
plt.plot(line_x, line_y, label="Regression line")
plt.xlabel("Years of experience")
plt.ylabel("Salary")
plt.legend()
plt.show()

years = float(input("Enter years of experience: "))
predicted_salary = model.predict([[years]])[0]
print("Estimated salary:", round(predicted_salary, 2))

# Q3: Robot Navigation Using A* on an 8 x 8 Grid
# Experiment 1: Informed Search Algorithms
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import heapq

# 0 means free cell; 1 means obstacle. The grid has 8 rows and 8 columns.
grid = [
    [0, 0, 0, 0, 1, 0, 0, 0],
    [1, 1, 0, 0, 1, 0, 1, 0],
    [0, 0, 0, 1, 0, 0, 1, 0],
    [0, 1, 0, 1, 0, 1, 0, 0],
    [0, 1, 0, 0, 0, 1, 0, 1],
    [0, 0, 0, 1, 0, 0, 0, 0],
    [1, 1, 0, 1, 0, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0]
]
start = (0, 0)
goal = (7, 7)

def manhattan(a, b):
    # Number of horizontal plus vertical steps in an obstacle-free grid.
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def astar_grid(start, goal):
    # Heap entries: (f score, g score, cell).
    queue = [(manhattan(start, goal), 0, start)]
    cost = {start: 0}
    parent = {start: None}
    explored = []
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    while queue:
        f, g, current = heapq.heappop(queue)
        if g != cost[current]:
            continue
        explored.append(current)
        if current == goal:
            break

        for dr, dc in directions:
            nr = current[0] + dr
            nc = current[1] + dc
            neighbour = (nr, nc)

            # Check grid boundary and obstacle before using the cell.
            if 0 <= nr < 8 and 0 <= nc < 8 and grid[nr][nc] == 0:
                new_cost = g + 1
                if neighbour not in cost or new_cost < cost[neighbour]:
                    cost[neighbour] = new_cost
                    parent[neighbour] = current
                    priority = new_cost + manhattan(neighbour, goal)
                    heapq.heappush(queue, (priority, new_cost, neighbour))

    if goal not in parent:
        return None, explored

    path = []
    cell = goal
    while cell is not None:
        path.append(cell)
        cell = parent[cell]
    path.reverse()
    return path, explored

path, explored = astar_grid(start, goal)
if path is None:
    print("No valid path exists.")
else:
    path_cells = set(path)
    print("Grid: S=start, G=goal, #=obstacle, *=path, .=free")
    for r in range(8):
        row = []
        for c in range(8):
            cell = (r, c)
            if cell == start:
                row.append("S")
            elif cell == goal:
                row.append("G")
            elif grid[r][c] == 1:
                row.append("#")
            elif cell in path_cells:
                row.append("*")
            else:
                row.append(".")
        print(" ".join(row))
    print("Path:", path)
    print("Path length:", len(path) - 1, "moves")
    print("Cells explored:", len(explored))

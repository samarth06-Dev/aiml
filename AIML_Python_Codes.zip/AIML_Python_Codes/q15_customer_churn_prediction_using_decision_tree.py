# Q15: Customer Churn Prediction Using Decision Tree
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: Telco churn CSV, such as the common IBM Telco Customer Churn dataset. Expected target column: `Churn` with Yes/No values.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, accuracy_score

# Expected Telco churn file: telco_churn.csv, with target column Churn.
df = pd.read_csv("telco_churn.csv")
if "customerID" in df.columns:
    df = df.drop(columns=["customerID"])

# TotalCharges may be stored as text even though it represents a number.
if "TotalCharges" in df.columns:
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

y = df["Churn"].map({"Yes": 1, "No": 0})
X = df.drop(columns=["Churn"])
X = pd.get_dummies(X, drop_first=True, dtype=int)
X = X.fillna(X.median())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
model = DecisionTreeClassifier(max_depth=5, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, predictions))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))
print("Precision:", precision_score(y_test, predictions, zero_division=0))
print("Recall:", recall_score(y_test, predictions, zero_division=0))
print("F1-score:", f1_score(y_test, predictions, zero_division=0))

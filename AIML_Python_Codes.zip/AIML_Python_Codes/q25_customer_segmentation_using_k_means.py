# Q25: Customer Segmentation Using K-Means
# Experiment 6: Ensemble Learning and K-Means Clustering
# Dataset / setup: Mall Customers CSV. Expected headers: `Annual Income (k$)` and `Spending Score (1-100)`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# Expected file: Mall_Customers.csv.
df = pd.read_csv("Mall_Customers.csv")
features = ["Annual Income (k$)", "Spending Score (1-100)"]
X = df[features].dropna()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Elbow method: compare inertia for K from 1 to 10.
inertias = []
for k in range(1, 11):
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(X_scaled)
    inertias.append(model.inertia_)

plt.plot(range(1, 11), inertias, marker="o")
plt.xlabel("Number of clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Method")
plt.show()

# Choose K after inspecting the elbow plot; 5 is a common demonstration value.
chosen_k = 5
kmeans = KMeans(n_clusters=chosen_k, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)

# Plot clusters in the original two-feature scale.
plt.scatter(X[features[0]], X[features[1]], c=labels)
centres = scaler.inverse_transform(kmeans.cluster_centers_)
plt.scatter(centres[:, 0], centres[:, 1], marker="X", s=200, label="Centroids")
plt.xlabel(features[0])
plt.ylabel(features[1])
plt.legend()
plt.title("Customer Segments")
plt.show()

for cluster in range(chosen_k):
    print("Cluster", cluster, "customers:", sum(labels == cluster))

# Q13: Compare Regression Models With and Without PCA
# Experiment 4: EDA, PCA and Regression
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# The built-in Diabetes dataset is numerical and is available with scikit-learn.
data = load_diabetes()
X = data.data
y = data.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# Model A: original features (no PCA).
scaler_a = StandardScaler()
X_train_a = scaler_a.fit_transform(X_train)
X_test_a = scaler_a.transform(X_test)
model_a = LinearRegression()
model_a.fit(X_train_a, y_train)
pred_a = model_a.predict(X_test_a)

# Model B: standardized features transformed by PCA.
scaler_b = StandardScaler()
X_train_scaled = scaler_b.fit_transform(X_train)
X_test_scaled = scaler_b.transform(X_test)
pca = PCA(n_components=0.95)
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)
model_b = LinearRegression()
model_b.fit(X_train_pca, y_train)
pred_b = model_b.predict(X_test_pca)

def evaluate(name, actual, predicted):
    print(name)
    print("R2:", round(r2_score(actual, predicted), 3))
    print("RMSE:", round(mean_squared_error(actual, predicted) ** 0.5, 3))
    print("MAE:", round(mean_absolute_error(actual, predicted), 3))

evaluate("Without PCA", y_test, pred_a)
evaluate("With PCA", y_test, pred_b)
print("Features before PCA:", X_train.shape[1])
print("Components after PCA:", pca.n_components_)

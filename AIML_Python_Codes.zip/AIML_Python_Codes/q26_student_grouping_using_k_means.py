# Q26: Student Grouping Using K-Means
# Experiment 6: Ensemble Learning and K-Means Clustering
# Dataset / setup: Student performance CSV. Expected numerical columns: `attendance`, `internal_marks`, and `assignment_score`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

# Expected columns: attendance, internal_marks, assignment_score.
df = pd.read_csv("student_performance.csv")
features = ["Hours Studied", "Previous Scores", "Sample Question Papers Practiced"]
X = df[features].dropna()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Use the elbow method to compare candidate K values.
inertias = []
for k in range(1, 8):
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(X_scaled)
    inertias.append(model.inertia_)
plt.plot(range(1, 8), inertias, marker="o")
plt.xlabel("K")
plt.ylabel("Inertia")
plt.title("Elbow Method for Student Groups")
plt.show()

chosen_k = 3  # Adjust this after examining the elbow plot.
kmeans = KMeans(n_clusters=chosen_k, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)

# PCA converts the three standardized inputs into two plotting coordinates.
pca = PCA(n_components=2)
points_2d = pca.fit_transform(X_scaled)
plt.scatter(points_2d[:, 0], points_2d[:, 1], c=labels)
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("Student Clusters (PCA Projection)")
plt.show()

# Print the average original feature values in each group.
result = X.copy()
result["Cluster"] = labels
print(result.groupby("Cluster")[features].mean())

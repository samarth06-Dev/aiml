# Q17: Decision Tree Optimization: Entropy vs Gini
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Load Iris as a simple multi-class dataset.
data = load_iris()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Train and compare one Gini tree and one Entropy tree.
gini_tree = DecisionTreeClassifier(criterion="gini", random_state=42)
entropy_tree = DecisionTreeClassifier(criterion="entropy", random_state=42)
gini_tree.fit(X_train, y_train)
entropy_tree.fit(X_train, y_train)
print("Gini accuracy:", accuracy_score(y_test, gini_tree.predict(X_test)))
print("Entropy accuracy:", accuracy_score(y_test, entropy_tree.predict(X_test)))
print("Gini depth/leaves:", gini_tree.get_depth(), gini_tree.get_n_leaves())
print("Entropy depth/leaves:", entropy_tree.get_depth(), entropy_tree.get_n_leaves())

# Try several values and select the best using 5-fold cross-validation.
parameter_grid = {
    "criterion": ["gini", "entropy"],
    "max_depth": [2, 3, 4, None],
    "min_samples_leaf": [1, 2, 4]
}
search = GridSearchCV(DecisionTreeClassifier(random_state=42),
                      parameter_grid, cv=5, scoring="accuracy")
search.fit(X_train, y_train)
best_model = search.best_estimator_
print("Best parameters:", search.best_params_)
print("Best cross-validation score:", search.best_score_)
print("Tuned test accuracy:", accuracy_score(y_test, best_model.predict(X_test)))

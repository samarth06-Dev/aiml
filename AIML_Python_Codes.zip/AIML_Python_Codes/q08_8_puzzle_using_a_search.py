# Q8: 8-Puzzle Using A* Search
# Experiment 3: Game Playing and Puzzle Solving
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import heapq

start = (1, 2, 3,
         4, 0, 6,
         7, 5, 8)
goal = (1, 2, 3,
        4, 5, 6,
        7, 8, 0)

def manhattan(state):
    # Sum each numbered tile's distance from its goal position.
    distance = 0
    for index, tile in enumerate(state):
        if tile == 0:
            continue  # The blank is not counted.
        goal_index = goal.index(tile)
        row1, col1 = divmod(index, 3)
        row2, col2 = divmod(goal_index, 3)
        distance += abs(row1 - row2) + abs(col1 - col2)
    return distance

def neighbours(state):
    # Generate states by moving the blank one legal step.
    zero = state.index(0)
    row, col = divmod(zero, 3)
    moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    result = []
    for dr, dc in moves:
        nr, nc = row + dr, col + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_index = nr * 3 + nc
            new_state = list(state)
            new_state[zero], new_state[new_index] = new_state[new_index], new_state[zero]
            result.append(tuple(new_state))
    return result

def solve_a_star():
    queue = [(manhattan(start), 0, start)]  # (f, g, state)
    cost = {start: 0}
    parent = {start: None}
    explored = 0

    while queue:
        f, g, state = heapq.heappop(queue)
        if g != cost[state]:
            continue
        explored += 1
        if state == goal:
            path = []
            current = goal
            while current is not None:
                path.append(current)
                current = parent[current]
            return path[::-1], explored

        for next_state in neighbours(state):
            new_cost = g + 1
            if next_state not in cost or new_cost < cost[next_state]:
                cost[next_state] = new_cost
                parent[next_state] = state
                heapq.heappush(queue, (new_cost + manhattan(next_state),
                                       new_cost, next_state))
    return None, explored

def display(state):
    for i in range(0, 9, 3):
        print(state[i:i + 3])
    print()

path, explored = solve_a_star()
if path:
    for step, state in enumerate(path):
        print("Step", step)
        display(state)
    print("Number of moves:", len(path) - 1)
    print("States explored:", explored)
else:
    print("No solution found for this starting state.")

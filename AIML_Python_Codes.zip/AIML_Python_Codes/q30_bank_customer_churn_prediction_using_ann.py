# Q30: Bank Customer Churn Prediction Using ANN
# Experiment 8: Artificial Neural Networks
# Dataset / setup: Bank Customer Churn Modeling CSV. Expected target `Exited`; common file name `Churn_Modelling.csv`.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

# Install TensorFlow if needed: pip install tensorflow
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# Expected Kaggle Bank Churn CSV with target column Exited (0/1).
df = pd.read_csv("Churn_Modelling.csv")
# Remove identifier/name columns if present.
remove_columns = [c for c in ["RowNumber", "CustomerId", "Surname"] if c in df.columns]
df = df.drop(columns=remove_columns)

y = df["Exited"]
X = df.drop(columns=["Exited"])
# Convert Geography and Gender (and any other text columns) into numeric columns.
X = pd.get_dummies(X, drop_first=True, dtype=int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Build a small feed-forward neural network.
model = Sequential([
    Dense(16, activation="relu", input_shape=(X_train_scaled.shape[1],)),
    Dense(8, activation="relu"),
    Dense(1, activation="sigmoid")
])

# Configure training for binary classification.
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
model.fit(X_train_scaled, y_train, epochs=20, batch_size=32, validation_split=0.1)

# Predict probabilities, then convert them to 0/1 labels.
probabilities = model.predict(X_test_scaled)
predictions = (probabilities >= 0.5).astype(int).ravel()
print("Accuracy:", accuracy_score(y_test, predictions))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

# Q33: End-to-End Machine Learning Pipeline
# Experiment 9: Integrated Classification and ML Pipeline
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

# Step 1: Choose a labelled dataset and define the target.
data = load_breast_cancer()
X, y = data.data, data.target
print("Dataset shape:", X.shape)
print("Class labels:", data.target_names)

# Step 2: Create a stratified hold-out test set.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Step 3: Define preprocessing and model as one pipeline.
pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
    ("classifier", LogisticRegression(max_iter=2000))
])

# Step 4: Tune one hyperparameter using cross-validation on training data only.
parameter_grid = {"classifier__C": [0.01, 0.1, 1, 10]}
search = GridSearchCV(pipeline, parameter_grid, cv=5, scoring="accuracy")
search.fit(X_train, y_train)

# Step 5: Evaluate the selected pipeline once on the hold-out test set.
best_model = search.best_estimator_
predictions = best_model.predict(X_test)
print("Best parameters:", search.best_params_)
print("Best cross-validation accuracy:", search.best_score_)
print("Test accuracy:", accuracy_score(y_test, predictions))
print("Precision:", precision_score(y_test, predictions))
print("Recall:", recall_score(y_test, predictions))
print("F1-score:", f1_score(y_test, predictions))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

# Q6: Examination Timetable Scheduling Using CSP
# Experiment 2: Constraint Satisfaction Problems (CSP)
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

# Six exams and the students enrolled in each exam (sample data).
enrollments = {
    "Maths": {"S1", "S2"},
    "DBMS": {"S2", "S3"},
    "Python": {"S4", "S5"},
    "Networks": {"S3", "S6"},
    "OS": {"S5", "S7"},
    "AI": {"S1", "S6"}
}
slots = ["Slot 1", "Slot 2", "Slot 3", "Slot 4"]

# Build a conflict set for every exam.
conflicts = {exam: set() for exam in enrollments}
exams = list(enrollments)
for i in range(len(exams)):
    for j in range(i + 1, len(exams)):
        first = exams[i]
        second = exams[j]
        if enrollments[first] & enrollments[second]:
            conflicts[first].add(second)
            conflicts[second].add(first)

def schedule(index, timetable):
    # All exams have been assigned a slot.
    if index == len(exams):
        return True

    exam = exams[index]
    for slot in slots:
        # A conflicting exam must not already use this slot.
        clash = False
        for other_exam in conflicts[exam]:
            if timetable.get(other_exam) == slot:
                clash = True
                break

        if not clash:
            timetable[exam] = slot  # Assign this exam temporarily.
            if schedule(index + 1, timetable):
                return True
            del timetable[exam]  # Backtrack if later exams cannot fit.
    return False

print("Exam conflict pairs:")
for exam in exams:
    for other in conflicts[exam]:
        if exams.index(exam) < exams.index(other):
            print(exam, "-", other)

result = {}
if schedule(0, result):
    print("\nValid timetable:")
    for exam in exams:
        print(exam, "->", result[exam])
    print("No conflicting exams share a slot.")
else:
    print("No valid timetable: available slots are insufficient.")

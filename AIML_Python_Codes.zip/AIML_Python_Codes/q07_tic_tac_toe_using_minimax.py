# Q7: Tic-Tac-Toe Using Minimax
# Experiment 3: Game Playing and Puzzle Solving
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

# Empty cells contain a space; the human plays X and the computer plays O.
board = [" "] * 9

def show_board():
    print()
    for row in range(3):
        print(" | ".join(board[row * 3:(row + 1) * 3]))
        if row < 2:
            print("---------")

def winner(player):
    # All possible rows, columns and diagonals.
    wins = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
            (0, 3, 6), (1, 4, 7), (2, 5, 8),
            (0, 4, 8), (2, 4, 6)]
    return any(board[a] == board[b] == board[c] == player for a, b, c in wins)

def minimax(is_maximizing):
    # Terminal states receive a score.
    if winner("O"):
        return 1
    if winner("X"):
        return -1
    if " " not in board:
        return 0

    if is_maximizing:  # Computer tries to maximize the score.
        best = -float("inf")
        for i in range(9):
            if board[i] == " ":
                board[i] = "O"
                best = max(best, minimax(False))
                board[i] = " "  # Undo the test move.
        return best
    else:  # Human is assumed to minimize the computer's score.
        best = float("inf")
        for i in range(9):
            if board[i] == " ":
                board[i] = "X"
                best = min(best, minimax(True))
                board[i] = " "
        return best

def computer_move():
    best_score = -float("inf")
    chosen = None
    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            score = minimax(False)
            board[i] = " "
            if score > best_score:
                best_score = score
                chosen = i
    if chosen is not None:
        board[chosen] = "O"

print("Positions are numbered 1 to 9 from left to right, top to bottom.")
while True:
    show_board()
    move = int(input("Your move (1-9): ")) - 1
    if move < 0 or move > 8 or board[move] != " ":
        print("Invalid or occupied position. Try again.")
        continue
    board[move] = "X"

    if winner("X"):
        show_board()
        print("You win.")
        break
    if " " not in board:
        show_board()
        print("Draw.")
        break

    computer_move()
    if winner("O"):
        show_board()
        print("Computer wins.")
        break
    if " " not in board:
        show_board()
        print("Draw.")
        break

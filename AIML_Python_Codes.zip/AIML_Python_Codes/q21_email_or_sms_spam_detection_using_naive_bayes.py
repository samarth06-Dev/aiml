# Q21: Email or SMS Spam Detection Using Naive Bayes
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: Spam CSV such as the SMS Spam Collection. Expected columns `label` and `message`, or common `v1` and `v2` columns.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, accuracy_score

# Expected file spam.csv with columns: label (spam/ham) and message.
df = pd.read_csv("spam.csv", encoding="latin-1")
# Common SMS Spam Collection files use v1 and v2; rename them if present.
if "v1" in df.columns and "v2" in df.columns:
    df = df.rename(columns={"v1": "label", "v2": "message"})

df = df[["spam", "text"]].dropna()
X = df["text"].astype(str)
y = df["spam"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Pipeline ensures TF-IDF is fitted only on the training text.
model = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english")),
    ("naive_bayes", MultinomialNB())
])
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, predictions))
print("Precision:", precision_score(y_test, predictions, zero_division=0))
print("Recall:", recall_score(y_test, predictions, zero_division=0))
print("F1-score:", f1_score(y_test, predictions, zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

new_message = [input("Enter a message to classify: ")]
result = model.predict(new_message)[0]
print("Spam" if result == 1 else "Not spam")

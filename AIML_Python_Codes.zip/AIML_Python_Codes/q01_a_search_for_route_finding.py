# Q1: A* Search for Route Finding
# Experiment 1: Informed Search Algorithms
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import heapq
import math

# Each city is connected to its neighbours with a travel cost.
graph = {
    "Pune": {"Mumbai": 150, "Nashik": 210, "Satara": 110},
    "Mumbai": {"Pune": 150, "Surat": 280, "Nashik": 170},
    "Nashik": {"Pune": 210, "Mumbai": 170, "Aurangabad": 190},
    "Aurangabad": {"Nashik": 190, "Nagpur": 500},
    "Nagpur": {"Aurangabad": 500, "Satara": 700},
    "Satara": {"Pune": 110, "Nagpur": 700, "Kolhapur": 180},
    "Kolhapur": {"Satara": 180, "Goa": 230},
    "Goa": {"Kolhapur": 230, "Surat": 650},
    "Surat": {"Mumbai": 280, "Goa": 650, "Nagpur": 850}
}

# Approximate map coordinates; straight-line distance is our heuristic.
coordinates = {
    "Pune": (0, 0), "Mumbai": (120, 0), "Nashik": (110, 140),
    "Aurangabad": (300, 150), "Nagpur": (750, 230),
    "Satara": (-60, -100), "Kolhapur": (-150, -250),
    "Goa": (-300, -350), "Surat": (390, -20)
}

def heuristic(city, goal):
    # Euclidean distance estimates the distance remaining to the goal.
    x1, y1 = coordinates[city]
    x2, y2 = coordinates[goal]
    # The 0.5 factor keeps this straight-line estimate conservative for the sample edge costs.
    return 0.5 * math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

def a_star(start, goal):
    # Heap items are (estimated total cost, actual cost, current city).
    queue = [(heuristic(start, goal), 0, start)]
    cost = {start: 0}          # Best known g(n) for each city.
    parent = {start: None}     # Used later to rebuild the route.
    explored = []

    while queue:
        f, current_cost, current = heapq.heappop(queue)

        # Ignore an old queue entry if a cheaper route was found later.
        if current_cost != cost[current]:
            continue

        explored.append(current)
        if current == goal:
            break

        for neighbour, edge_cost in graph[current].items():
            new_cost = current_cost + edge_cost
            if neighbour not in cost or new_cost < cost[neighbour]:
                cost[neighbour] = new_cost
                parent[neighbour] = current
                new_f = new_cost + heuristic(neighbour, goal)
                heapq.heappush(queue, (new_f, new_cost, neighbour))

    if goal not in parent:
        return None, None, explored

    # Follow parent links backwards, then reverse to get start -> goal.
    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = parent[node]
    path.reverse()
    return path, cost[goal], explored

# Read and validate the user\'s source and destination.
print("Available cities:", ", ".join(graph))
start = input("Enter source city: ").strip().title()
goal = input("Enter destination city: ").strip().title()

if start not in graph or goal not in graph:
    print("Invalid city name.")
elif start == goal:
    print("Source and destination are the same. Cost = 0")
else:
    path, total_cost, explored = a_star(start, goal)
    if path:
        print("Route:", " -> ".join(path))
        print("Total path cost:", total_cost)
        print("Nodes explored:", len(explored), explored)
    else:
        print("No route found.")

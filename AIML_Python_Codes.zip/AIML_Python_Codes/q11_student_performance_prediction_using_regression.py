# Q11: Student Performance Prediction Using Regression
# Experiment 4: EDA, PCA and Regression
# Dataset / setup: Student performance CSV. This example expects `study_hours`, `attendance`, `previous_marks`, and `final_score`; rename dataset columns as needed.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Prepare student_performance.csv with these columns or rename your columns accordingly.
df = pd.read_csv("student_performance.csv")
features = ["Hours Studied", "Sleep Hours", "Previous Scores"]
target = "Performance Index"

X = df[features].copy()
y = df[target]
X = X.fillna(X.median())  # Fill missing input values using column medians.

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("R2:", r2_score(y_test, predictions))
print("RMSE:", mean_squared_error(y_test, predictions) ** 0.5)
print("MAE:", mean_absolute_error(y_test, predictions))

# Display each feature's learned coefficient.
for feature, coefficient in zip(features, model.coef_):
    print(feature, "coefficient:", round(coefficient, 3))
print("Intercept:", round(model.intercept_, 3))

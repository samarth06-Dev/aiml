# Q28: Evaluate K-Means for Different Cluster Counts
# Experiment 6: Ensemble Learning and K-Means Clustering
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

# Iris provides four numerical features, so no CSV is required.
data = load_iris()
X = data.data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

inertias = []
silhouette_values = []
ks = [2, 3, 4, 5]
for k in ks:
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = model.fit_predict(X_scaled)
    inertias.append(model.inertia_)
    silhouette_values.append(silhouette_score(X_scaled, labels))
    print("K =", k, "Inertia =", model.inertia_,
          "Silhouette =", silhouette_values[-1])

plt.plot(ks, inertias, marker="o")
plt.xlabel("Number of clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Evaluation")
plt.show()

plt.plot(ks, silhouette_values, marker="o")
plt.xlabel("Number of clusters (K)")
plt.ylabel("Silhouette score")
plt.title("Silhouette Evaluation")
plt.show()

# Choose a final K after comparing both evaluation results.
chosen_k = 3
final_model = KMeans(n_clusters=chosen_k, random_state=42, n_init=10)
final_labels = final_model.fit_predict(X_scaled)

# Project the standardized four-dimensional features into two dimensions.
pca = PCA(n_components=2)
X_2d = pca.fit_transform(X_scaled)
plt.scatter(X_2d[:, 0], X_2d[:, 1], c=final_labels)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("Final K-Means Clusters")
plt.show()

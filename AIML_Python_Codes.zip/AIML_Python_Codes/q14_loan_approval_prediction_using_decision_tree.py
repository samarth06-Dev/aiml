# Q14: Loan Approval Prediction Using Decision Tree
# Experiment 5: Decision Tree, KNN and Naive Bayes
# Dataset / setup: Loan approval CSV. Expected target is `Loan_Status`; code optionally drops `Loan_ID`. Change names to match the provided dataset.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

# Expected file: loan_data.csv; target column: Loan_Status (Y/N or 1/0).
df = pd.read_csv("loan_data.csv")
target = "Loan_Status"
if "Loan_ID" in df.columns:
    df = df.drop(columns=["Loan_ID"])  # Identifier is not a useful predictor.

# Convert approval labels to numbers.
y = df[target].replace({"Y": 1, "N": 0, "Yes": 1, "No": 0})
X = df.drop(columns=[target])
X = pd.get_dummies(X, drop_first=True, dtype=int)
X = X.fillna(X.median())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

model = DecisionTreeClassifier(criterion="gini", max_depth=4, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, predictions))
print("Precision:", precision_score(y_test, predictions, zero_division=0))
print("Recall:", recall_score(y_test, predictions, zero_division=0))
print("F1-score:", f1_score(y_test, predictions, zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, predictions))

plt.figure(figsize=(14, 7))
plot_tree(model, feature_names=X.columns, class_names=["Rejected", "Approved"],
          filled=True, rounded=True)
plt.show()

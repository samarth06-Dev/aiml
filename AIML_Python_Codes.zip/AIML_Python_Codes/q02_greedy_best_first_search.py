# Q2: Greedy Best-First Search
# Experiment 1: Informed Search Algorithms
# Dataset / setup: No external dataset required.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import heapq
import math

graph = {
    "Pune": {"Mumbai": 150, "Nashik": 210, "Satara": 110},
    "Mumbai": {"Pune": 150, "Surat": 280, "Nashik": 170},
    "Nashik": {"Pune": 210, "Mumbai": 170, "Aurangabad": 190},
    "Aurangabad": {"Nashik": 190, "Nagpur": 500},
    "Nagpur": {"Aurangabad": 500, "Satara": 700},
    "Satara": {"Pune": 110, "Nagpur": 700, "Kolhapur": 180},
    "Kolhapur": {"Satara": 180, "Goa": 230},
    "Goa": {"Kolhapur": 230, "Surat": 650},
    "Surat": {"Mumbai": 280, "Goa": 650, "Nagpur": 850}
}
coordinates = {
    "Pune": (0, 0), "Mumbai": (120, 0), "Nashik": (110, 140),
    "Aurangabad": (300, 150), "Nagpur": (750, 230),
    "Satara": (-60, -100), "Kolhapur": (-150, -250),
    "Goa": (-300, -350), "Surat": (390, -20)
}

def heuristic(city, goal):
    # Straight-line distance is used only to guide the search.
    x1, y1 = coordinates[city]
    x2, y2 = coordinates[goal]
    # The 0.5 factor keeps this straight-line estimate conservative for the sample edge costs.
    return 0.5 * math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

def greedy_best_first(start, goal):
    # Priority is h(n), not g(n) + h(n).
    queue = [(heuristic(start, goal), start)]
    visited = set()
    parent = {start: None}
    explored = []

    while queue:
        h, current = heapq.heappop(queue)
        if current in visited:
            continue
        visited.add(current)
        explored.append(current)

        if current == goal:
            break

        for neighbour in graph[current]:
            if neighbour not in visited and neighbour not in parent:
                parent[neighbour] = current
                heapq.heappush(queue, (heuristic(neighbour, goal), neighbour))

    if goal not in visited:
        return None, None, explored

    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = parent[node]
    path.reverse()

    # Calculate the route's actual cost after finding the route.
    total_cost = 0
    for i in range(len(path) - 1):
        total_cost += graph[path[i]][path[i + 1]]
    return path, total_cost, explored

print("Available cities:", ", ".join(graph))
start = input("Enter source city: ").strip().title()
goal = input("Enter destination city: ").strip().title()

if start not in graph or goal not in graph:
    print("Invalid city name.")
elif start == goal:
    print("Route:", start, "| Cost: 0 | Nodes explored: 1")
else:
    path, total_cost, explored = greedy_best_first(start, goal)
    if path:
        print("Route:", " -> ".join(path))
        print("Total path cost:", total_cost)
        print("Nodes explored:", len(explored), explored)
    else:
        print("No route found.")

# Q10: House Price Prediction Using Linear Regression
# Experiment 4: EDA, PCA and Regression
# Dataset / setup: Housing CSV. The sample expects a target column named `price`; change this one name to match your file. All remaining columns are treated as features.
# Read the accompanying AIML_Practical_Exam_Study_Guide.docx for theory and viva notes.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Expected file: Housing.csv. Change target name if your dataset uses another name.
df = pd.read_csv("Housing.csv")
print("Shape:", df.shape)
print("Missing values:\n", df.isnull().sum())
print(df.describe(include="all"))

target = "Price"
# Separate input columns from the value we want to predict.
X = df.drop(columns=[target])
y = df[target]

# Convert text categories (for example, yes/no or furnishing status) to 0/1 columns.
X = pd.get_dummies(X, drop_first=True, dtype=int)

# Fill missing numeric input values with their column median.
X = X.fillna(X.median())

# Split first so test records are not used to train the prediction model.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("R2:", r2_score(y_test, predictions))
print("RMSE:", mean_squared_error(y_test, predictions) ** 0.5)
print("MAE:", mean_absolute_error(y_test, predictions))

# Compare actual and predicted prices visually.
plt.scatter(y_test, predictions)
plt.xlabel("Actual house price")
plt.ylabel("Predicted house price")
plt.title("Actual vs Predicted House Prices")
plt.show()
